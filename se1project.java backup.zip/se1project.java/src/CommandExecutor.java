import java.util.HashMap;
import java.util.Map;
import service.Container;

public class CommandExecutor {
    private final Map<String, Command> commands = new HashMap<>();
    private final UndoCommand undoCommand = new UndoCommand();

    public CommandExecutor(Container container) {
        registerCommands(container);
    }

    private void registerCommands(Container container) {
        commands.put("enter", new EnterCommand());
        commands.put("store", new StoreCommand());
        commands.put("load", new LoadCommand());
        commands.put("dump", new DumpCommand());
        commands.put("analyze", new AnalyzeCommand());//
        commands.put("undo", new UndoCommand());
        commands.put("clean", new CleanCommand());
        commands.put("help", new HelpCommand());
    }

    public void execute(String input) {
        String[] tokens = input.split(" ", 2);
        String command = tokens[0].toLowerCase();

        if (commands.containsKey(command)) {
            commands.get(command).execute(tokens, Container.getInstance());
        } else {
            System.out.println("Invalid command. Type 'help' for available commands.");
        }
    }

    public void addUndoAction(Runnable action) {
        undoCommand.addUndoAction(action);
    }
}
