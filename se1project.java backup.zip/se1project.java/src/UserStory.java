import java.io.Serializable;

class UserStory implements Serializable {
    private static final long serialVersionUID = 1L;  // Add this for serialization
    private int id;
    private String description;
    private String actor;
    private double effort;
    private double value;
    private double risk;
    private double penalty;
    private String goal;
    private String benefit;

    public UserStory(int id, String description, double effort, double value, double risk, double penalty) {
        this.id = id;
        this.description = description;
        this.actor = "";
        this.effort = effort;
        this.value = value;
        this.risk = risk;
        this.penalty = penalty;
        this.goal = "";
        this.benefit = "";
    }

    public double calculatePriority() {
        return (value + penalty) / (effort + risk); 
    }

    public int getId() {
        return id;
    }

    public String getActor(){
        return actor;
    }

    public void setActor(){
        this.actor = actor;
    }

    public String getGoal() {
        return goal;
    }

    public String getBenefit() {
        return benefit;
    }

    // Analyze the quality of the user story
    public double analyzeStoryQuality() {
        double clarityScore = analyzeClarity();
        double completenessScore = analyzeCompleteness();
        double feasibilityScore = analyzeFeasibility();
        double valueScore = analyzeValue();

        // Calculate the overall quality as an average of the metrics
        double overallScore = (clarityScore + completenessScore + feasibilityScore + valueScore) / 4;
        return overallScore;
    }

    private double analyzeClarity() {
        // Example: Score based on length and readability
        if (description == null || description.isEmpty()) return 0;
        int wordCount = description.split("\\s+").length;
        return (wordCount >= 5 && wordCount <= 50) ? 100 : 50;
    }

    private double analyzeCompleteness() {
        // Check if essential attributes are filled and valid
        boolean validEffort = effort > 0;
        boolean validValue = value > 0;
        boolean validRisk = risk >= 0 && risk <= 1;
        boolean validPenalty = penalty > 0;

        return (validEffort && validValue && validRisk && validPenalty) ? 100 : 50;
    }

    private double analyzeFeasibility() {
        // Effort should be within a reasonable range
        return (effort > 0 && effort <= 100) ? 100 : 50;
    }

    private double analyzeValue() {
        // High value and low risk are preferred
        if (value > 0) {
            double normalizedRisk = (1 - risk);  // Lower risk increases score
            return (value * normalizedRisk) > 50 ? 100 : 75;
        }
        return 50;
    }
    
    public void setGoal(String goal) {
        this.goal = goal;
    }

    public void setBenefit(String benefit) {
        this.benefit = benefit;
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Description: " + description + ", Priority: " + String.format("%.2f", calculatePriority());
    }
}
