public interface Command {
    void execute(String[] args, Container container);
}
