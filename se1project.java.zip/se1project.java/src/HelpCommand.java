public class HelpCommand implements Command {
    @Override
    public void execute(String[] args, Container container) {
        System.out.println("Available commands:");
        System.out.println("enter <id> <description> <effort> <value> <risk> - Enter a new user story");
        System.out.println("dump - Display all user stories sorted by priority");
        System.out.println("analyze <id> | analyze -all | analyze <id> -details | analyze <id> -details -hints - Analyze user stories");
        System.out.println("addElement -actor <name> - Register a new actor");
        System.out.println("load - Load user stories from the file");
        System.out.println("store - Store user stories to the file");
        System.out.println("analyze - Analyze the quality of all user stories");
        System.out.println("undo - Undo the last action");
        System.out.println("help - Show this help message");
        System.out.println("exit - Exit the program");
    }
}
