import java.io.*;
import java.util.List;
import java.util.Scanner;
import java.util.Stack;

public class main {
    static Container container = new Container();
    static Stack<String[]> commandHistory = new Stack<>();
    static final String FILE_NAME = "userStories.dat";  // File to store user stories

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to the PrioTool CLI.");
        System.out.println("Type 'help' for a list of commands.");

        // Load stored user stories at the start
        loadStories();

        while (true) {
            System.out.print("> ");
            String input = scanner.nextLine().trim();
            String[] tokens = input.split(" ", 2);

            if (tokens.length < 1 || tokens[0].isEmpty()) {
                System.out.println("Invalid input. Please try again.");
                continue;
            }

            String command = tokens[0].toLowerCase();

            switch (command) {
                case "help":
                    printHelp();
                    break;
                case "enter":
                    if (tokens.length < 2) {
                        System.out.println("Invalid input. Usage: enter <id> \"<description>\" <effort> <value> <risk> <penalty>");
                    } else {
                        enter(tokens[1]);
                    }
                    break;
                case "dump":
                    container.dumpStories();
                    break;
                case "load":
                    loadStories();  // Load stories before exitting if turn on tool, it will display
                    break;
                case "store":
                    storeStories();
                    break;
                case "analyze":
                    analyzeStories();
                    break;
                case "clean":
                    cleanUserStories();
                    break;
                case "undo":
                    undo();
                    break;
                case "exit":
                    System.out.println("Exiting the PrioTool. Goodbye!");
                    storeStories();  // Save before exiting
                    scanner.close();
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid command. Type 'help' for available commands.");
            }
        }
    }

    public static void enter(String input) {
        try {
            // Split the input into parts based on quotes
            String[] parts = input.split("\"", 3);
    
            // Validate input format
            if (parts.length < 3 || parts[1].isEmpty()) {
                throw new IllegalArgumentException("Invalid input format. Usage: enter <id> \"<description>\" <effort> <value> <risk> <penalty>");
            }
    
            // Parse the ID and description
            int id = Integer.parseInt(parts[0].trim());
            String description = parts[1].trim();
    
            // Parse the remaining fields (effort, value, risk, penalty)
            String[] values = parts[2].trim().split("\\s+");
            if (values.length != 4) {
                throw new IllegalArgumentException("Expected effort, value, risk, and penalty fields.");
            }
    
            double effort = Double.parseDouble(values[0].trim());
            double value = Double.parseDouble(values[1].trim());
            double risk = Double.parseDouble(values[2].trim());
            double penalty = Double.parseDouble(values[3].trim());
    
            // Validate values
            if (effort <= 0) {
                throw new IllegalArgumentException("Effort must be positive.");
            }
            if (value <= 0) {
                throw new IllegalArgumentException("Value must be positive.");
            }
            /*if (risk < 0 || risk > 1) {
                throw new IllegalArgumentException("Risk must be between 0 and 1.");
            }*/
            if (risk <= 0){
                throw new IllegalArgumentException("Risk must be positive.");
            } 
            if (penalty < 0) {
                throw new IllegalArgumentException("Penalty must be non-negative.");
            }
    
            // Create the UserStory object
            UserStory story = new UserStory(id, description, effort, value, risk, penalty);
            
            // Add the story to the container
            container.getUserStories().addElement(story);  // Using addElement for compatibility
            System.out.println("User story added: " + story);
    
            // Save the command to the history for undo functionality
            commandHistory.push(new String[]{"enter", input});
    
        } catch (NumberFormatException e) {
            System.out.println("Invalid number format. Please check your input.");
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("An unexpected error occurred: " + e.getMessage());
            e.printStackTrace();
        }
    }
    

    public static void loadStories() {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(FILE_NAME))) {
            List<UserStory> loadedStories = (List<UserStory>) in.readObject();
            loadedStories.forEach(story -> {
                container.getUserStories().addElement(story);  // Using addElement
                System.out.println("Loaded and added story using addElement: " + story);  // Confirmation message
            });
            System.out.println("User stories loaded successfully.");
        } catch (FileNotFoundException e) {
            System.out.println("No previous data found. Starting fresh.");
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error loading user stories: " + e.getMessage());
        }
    }

    public static void storeStories() {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {
            out.writeObject(container.getUserStories());
            System.out.println("User stories stored successfully.");
        } catch (IOException e) {
            System.out.println("Error saving user stories: " + e.getMessage());
        }
    }

    public static void analyzeStories() {
        System.out.println("Analyzing user story quality...");
        if (container.getUserStories().isEmpty()) {
            System.out.println("No user stories available to analyze.");
            return;
        }
        for (UserStory story : container.getUserStories()) {
            try {
                double qualityScore = story.analyzeStoryQuality();
                System.out.println(story + ", Quality Score: " + String.format("%.2f", qualityScore) + "%");
            
                //Leave a comment for quality score
                if (qualityScore <= 100 && qualityScore >= 90) {
                    System.out.println("Very Good");
                    } 
                else if (qualityScore < 90 && qualityScore >= 80) {
                    System.out.println("Good");
                    } 
                else if (qualityScore < 80 && qualityScore >= 70) {
                    System.out.println("Satisfactory");
                    }
                else if (qualityScore < 70){
                    System.out.println("Need improvement");
                }    

            } catch (Exception e) {
                System.out.println("Error analyzing story ID " + story.getId() + ": " + e.getMessage());
            }
        }
    }

    public static void undo() {
        if (commandHistory.isEmpty()) {
            System.out.println("Nothing to undo.");
            return;
        }

        String[] lastCommand = commandHistory.pop();
        String command = lastCommand[0];
        String data = lastCommand[1];

        switch (command) {
            case "enter":
                undoEnter(data);
                break;
            default:
                System.out.println("Undo not supported for the last command.");
        }
    }

    private static void undoEnter(String data) {
        try {
            String[] parts = data.split("\"", 2);
            int id = Integer.parseInt(parts[0].trim());

            if (container.removeUserStory(id)) {
                System.out.println("Undo successful: Removed user story with ID " + id);
            } else {
                System.out.println("Undo failed: Story with ID " + id + " not found.");
            }
        } catch (Exception e) {
            System.out.println("Error during undo: " + e.getMessage());
        }
    }

    public static void cleanUserStories(){
        container.cleanUserStories();
    }

    public static void printHelp() {
        System.out.println("Available commands:");
        System.out.println("enter <id> \"<description>\" <effort> <value> <risk> <penalty> - Enter a new user story");
        System.out.println("dump - Display all user stories sorted by priority");
        System.out.println("load - Load user stories from the file");
        System.out.println("store - Store user stories to the file");
        System.out.println("analyze - Analyze the quality of all user stories");
        System.out.println("undo - Undo the last action");
        System.out.println("clean - Cleaned old data");
        System.out.println("exit - Exit the program");
    }
}
