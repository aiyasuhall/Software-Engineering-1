public class DumpCommand implements Command {
    @Override
    public void execute(String[] args, Container container) {
        System.out.println("User Stories:");
        container.printUserStories();
    }
}
